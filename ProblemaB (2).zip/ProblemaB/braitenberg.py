import os
import csv
import time
import numpy as np
import matplotlib.pyplot as plt
from coppeliasim_zmqremoteapi_client import RemoteAPIClient

V_BASE     = 3.0
V_MAX      = 6.0
K_SENSOR   = 6.0
SENSOR_MAX = 1.0

WEIGHTS = [
    (+0.5, -0.5),
    (+1.0, -1.0),
    (+1.5, -1.5),
    (+2.0, -2.0),
    (-2.0, +2.0),
    (-1.5, +1.5),
    (-1.0, +1.0),
    (-0.5, +0.5),
]

NR_SENZORI  = len(WEIGHTS)
AFISARE_LA  = 20
PAUZA       = 0.05
FOLDER_TEMA = "tema"
FISIER_CSV  = os.path.join(FOLDER_TEMA, "log_braitenberg.csv")

def braitenberg_velocities(sim, sensors):
    v_left  = V_BASE
    v_right = V_BASE
    readings = []

    for i, (w_l, w_r) in enumerate(WEIGHTS):
        result, distance, *_ = sim.readProximitySensor(sensors[i])
        if result:
            proximity = max(0.0, min(1.0, 1.0 - distance / SENSOR_MAX))
        else:
            proximity = 0.0

        readings.append(proximity)
        v_left  += K_SENSOR * w_l * proximity
        v_right += K_SENSOR * w_r * proximity

    v_left  = max(-V_MAX, min(V_MAX, v_left))
    v_right = max(-V_MAX, min(V_MAX, v_right))

    return v_left, v_right, readings

def salveaza_csv(jurnal):
    os.makedirs(FOLDER_TEMA, exist_ok=True)
    antete = (
        ["timestamp", "v_left", "v_right"]
        + [f"s{i}" for i in range(NR_SENZORI)]
        + ["pos_x", "pos_y"]
    )
    with open(FISIER_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(antete)
        w.writerows(jurnal)
    print(f"CSV salvat: {FISIER_CSV} ({len(jurnal)} randuri)")

def genereaza_grafice(jurnal):
    date = np.array(jurnal, dtype=float)

    t       = date[:, 0]
    v_left  = date[:, 1]
    v_right = date[:, 2]
    senzori = date[:, 3 : 3 + NR_SENZORI]
    pos_x   = date[:, 3 + NR_SENZORI]
    pos_y   = date[:, 4 + NR_SENZORI]

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.plot(pos_x, pos_y, linewidth=1.5, color="royalblue")
    ax.scatter(pos_x[0], pos_y[0], color="green", s=70, zorder=5, label="Start")
    ax.scatter(pos_x[-1], pos_y[-1], color="red", s=70, zorder=5, label="Stop")
    ax.set_title("Traiectoria robotului (plan XY)")
    ax.set_xlabel("pos_x (m)")
    ax.set_ylabel("pos_y (m)")
    ax.set_aspect("equal", adjustable="datalim")
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend()
    fig.tight_layout()
    cale1 = os.path.join(FOLDER_TEMA, "1_traiectorie.png")
    fig.savefig(cale1, dpi=120)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(t, v_left, label="v_left", color="steelblue")
    ax.plot(t, v_right, label="v_right", color="darkorange", linestyle="--")
    ax.axhline(0, color="gray", linewidth=0.8, linestyle=":")
    ax.set_title("Vitezele motoarelor in timp")
    ax.set_xlabel("Timp (s)")
    ax.set_ylabel("Viteza (rad/s)")
    ax.legend()
    ax.grid(True, linestyle="--", alpha=0.5)
    fig.tight_layout()
    cale2 = os.path.join(FOLDER_TEMA, "2_viteze.png")
    fig.savefig(cale2, dpi=120)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(12, 4))
    im = ax.imshow(
        senzori.T,
        aspect="auto",
        cmap="YlOrRd",
        origin="lower",
        vmin=0.0, vmax=1.0,
        extent=[t[0], t[-1], -0.5, NR_SENZORI - 0.5],
    )
    fig.colorbar(im, ax=ax, label="Proximitate normalizata [0-1]")
    ax.set_yticks(range(NR_SENZORI))
    ax.set_yticklabels([f"S{i}" for i in range(NR_SENZORI)])
    ax.set_title("Heatmap activare senzori frontali S0-S7")
    ax.set_xlabel("Timp (s)")
    ax.set_ylabel("Senzor")
    fig.tight_layout()
    cale3 = os.path.join(FOLDER_TEMA, "3_heatmap_senzori.png")
    fig.savefig(cale3, dpi=120)
    plt.close(fig)

def main():
    client = RemoteAPIClient()
    sim    = client.require("sim")

    robot       = sim.getObject("/PioneerP3DX")
    left_motor  = sim.getObject("/PioneerP3DX/leftMotor")
    right_motor = sim.getObject("/PioneerP3DX/rightMotor")
    sensors     = [
        sim.getObject(f"/PioneerP3DX/ultrasonicSensor[{i}]")
        for i in range(8)
    ]

    jurnal   = []
    iteratie = 0

    sim.startSimulation()
    t_start = time.time()
    print("Vehicul Braitenberg pornit. Ctrl+C pentru oprire.")

    try:
        while True:
            timestamp = time.time() - t_start
            v_left, v_right, readings = braitenberg_velocities(sim, sensors)

            sim.setJointTargetVelocity(left_motor, v_left)
            sim.setJointTargetVelocity(right_motor, v_right)

            pos = sim.getObjectPosition(robot, sim.handle_world)
            pos_x, pos_y = pos[0], pos[1]

            jurnal.append(
                [round(timestamp, 4), round(v_left, 4), round(v_right, 4)]
                + [round(r, 4) for r in readings]
                + [round(pos_x, 4), round(pos_y, 4)]
            )

            if iteratie % AFISARE_LA == 0:
                print(f"t={timestamp:.2f}s | v_L={v_left:+.2f} | v_R={v_right:+.2f} | pos=({pos_x:.2f}, {pos_y:.2f})")

            iteratie += 1
            time.sleep(PAUZA)

    except KeyboardInterrupt:
        print("\nOprire vehicul.")
    finally:
        sim.setJointTargetVelocity(left_motor, 0.0)
        sim.setJointTargetVelocity(right_motor, 0.0)
        sim.stopSimulation()

    if jurnal:
        salveaza_csv(jurnal)
        genereaza_grafice(jurnal)
        print("Gata!")

if __name__ == "__main__":
    main()